import { useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, User } from 'firebase/auth'
import { getFirestore, collection, query, onSnapshot } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyBrb18G_x-SlG1MhiqNCPboM-reuU-3U4k",
  authDomain: "ak-play-5b1d8.firebaseapp.com",
  projectId: "ak-play-5b1d8",
  storageBucket: "ak-play-5b1d8.firebasestorage.app",
  messagingSenderId: "363917025025",
  appId: "1:363917025025:web:0980d683a95d90f8234500"
};

const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
const db = getFirestore(app)

function App() {
  const [user, setUser] = useState<User | null>(null)
  const [isSuperAdmin, setIsSuperAdmin] = useState(false)
  const [rooms, setRooms] = useState<any[]>([])
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  useEffect(() => {
    onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser)
      if (currentUser) {
        const token = await currentUser.getIdTokenResult()
        setIsSuperAdmin(token.claims.superadmin === true)
      }
    })
  }, [])

  useEffect(() => {
    if (!user) return
    const q = query(collection(db, 'rooms'))
    onSnapshot(q, (snapshot) => {
      setRooms(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })))
    })
  }, [user])

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
    } catch (error) {
      alert('Login failed: ' + error)
    }
  }

  if (!user) {
    return (
      <div style={{padding: '2rem', background: '#130d22', minHeight: '100vh', color: '#fff'}}>
        <h1 style={{textAlign: 'center', marginBottom: '2rem'}}>AK PLAY</h1>
        <input 
          style={{display: 'block', margin: '1rem 0', padding: '1rem', width: '100%', background: '#1a1430', border: '1px solid #2a2040', color: '#fff', borderRadius: '8px'}}
          type="email" 
          placeholder="Email" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input 
          style={{display: 'block', margin: '1rem 0', padding: '1rem', width: '100%', background: '#1a1430', border: '1px solid #2a2040', color: '#fff', borderRadius: '8px'}}
          type="password" 
          placeholder="Password" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin} style={{padding: '1rem', background: '#ff0055', color: '#fff', border: 'none', width: '100%', borderRadius: '8px', fontWeight: 'bold'}}>Login</button>
        <p style={{fontSize: '0.75rem', opacity: 0.6, marginTop: '2rem', textAlign: 'center'}}>Super Admin: jaiswalkunal734@gmail.com</p>
      </div>
    )
  }

  return (
    <div style={{padding: '1rem', background: '#130d22', minHeight: '100vh', color: '#fff'}}>
      <header style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', background: '#1a1430', padding: '1rem', borderRadius: '12px'}}>
        <h1>AK PLAY</h1>
        {isSuperAdmin && <span style={{background: '#ff0055', padding: '0.25rem 0.75rem', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 'bold'}}>SUPER ADMIN</span>}
        <button onClick={() => auth.signOut()} style={{padding: '0.5rem 1rem', background: '#2a2040', color: '#fff', border: 'none', borderRadius: '8px'}}>Logout</button>
      </header>
      
      {isSuperAdmin && (
        <div style={{background: '#2a2040', padding: '1rem', marginBottom: '1rem', borderRadius: '12px'}}>
          <h3 style={{marginBottom: '0.5rem'}}>Super Admin Panel</h3>
          <p style={{fontSize: '0.9rem', opacity: 0.8}}>Owner Room 20-seat control • User management</p>
        </div>
      )}
      
      <h2 style={{marginBottom: '1rem'}}>Game Rooms</h2>
      {rooms.length === 0 && <p style={{opacity: 0.6}}>No rooms available. Create one in Firestore.</p>}
      {rooms.map(room => (
        <div key={room.id} style={{background: '#1a1430', padding: '1rem', margin: '1rem 0', borderRadius: '12px', border: room.permanent ? '2px solid #ff0055' : '1px solid #2a2040'}}>
          <h3>{room.name || 'Room ' + room.id}</h3>
          <p style={{opacity: 0.8, margin: '0.5rem 0'}}>Seats: {room.seatCount || 6} {room.permanent && '(Permanent Owner Room)'}</p>
          <button style={{padding: '0.75rem 1.5rem', background: '#ff0055', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', marginTop: '0.5rem'}}>Join Room</button>
        </div>
      ))}
    </div>
  )
}

export default App